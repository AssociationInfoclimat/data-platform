-- TimescaleDB schema snapshot — ct-timescale db=postgres
-- Reconstruit depuis le catalogue (compte lecture seule, pg_dump indisponible) — 20260609
-- Structure seule, sans donnees

CREATE TABLE "public"."CommandeStation" (
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "id" text NOT NULL,
    "status" text DEFAULT 'pending'::text NOT NULL,
    "dateDebPeriode" timestamp(3) without time zone NOT NULL,
    "dateFinPeriode" timestamp(3) without time zone NOT NULL,
    "idStation" character(8) NOT NULL,
    "frequence" character varying(15) NOT NULL
);
CREATE UNIQUE INDEX "CommandeStation_pkey" ON public."CommandeStation" USING btree (id);

CREATE TABLE "public"."Decadaire" (
    "NUM_POSTE" character(8) NOT NULL,
    "NOM_USUEL" character varying(255) NOT NULL,
    "LAT" double precision NOT NULL,
    "LON" double precision NOT NULL,
    "ALTI" double precision NOT NULL,
    "AAAAMM" timestamp(3) without time zone NOT NULL,
    "NUM_DECADE" integer NOT NULL,
    "RR" double precision,
    "QRR" integer,
    "NBRR" integer,
    "RRAB" double precision,
    "QRRAB" integer,
    "RRABDAT" integer,
    "NBJRR1" integer,
    "NBJRR5" integer,
    "NBJRR10" integer,
    "NBJRR30" integer,
    "NBJRR50" integer,
    "NBJRR100" integer,
    "PMERM" double precision,
    "QPMERM" integer,
    "NBPMERM" integer,
    "PMERMINAB" double precision,
    "QPMERMINAB" integer,
    "PMERMINABDAT" integer,
    "TX" double precision,
    "QTX" integer,
    "NBTX" integer,
    "TXAB" double precision,
    "QTXAB" integer,
    "TXDAT" integer,
    "TXMIN" double precision,
    "QTXMIN" integer,
    "TXMINDAT" integer,
    "NBJTX0" integer,
    "NBJTX25" integer,
    "NBJTX30" integer,
    "NBJTX35" integer,
    "NBJTXI20" integer,
    "NBJTXI27" integer,
    "NBJTXS32" integer,
    "TN" double precision,
    "QTN" integer,
    "NBTN" integer,
    "TNAB" double precision,
    "QTNAB" integer,
    "TNDAT" integer,
    "TNMAX" double precision,
    "QTNMAX" integer,
    "TNMAXDAT" integer,
    "NBJTN5" integer,
    "NBJTN10" integer,
    "NBJTNI10" integer,
    "NBJTNI15" integer,
    "NBJTNI20" integer,
    "NBJTNS20" integer,
    "NBJTNS25" integer,
    "NBJGELEE" integer,
    "TAMPLIM" double precision,
    "QTAMPLIM" integer,
    "TAMPLIAB" double precision,
    "QTAMPLIAB" integer,
    "TAMPLIABDAT" integer,
    "NBTAMPLI" integer,
    "TM" double precision,
    "QTM" integer,
    "NBTM" integer,
    "TMM" double precision,
    "QTMM" integer,
    "NBTMM" integer,
    "NBJTMS24" integer,
    "TMMIN" double precision,
    "QTMMIN" integer,
    "TMMINDAT" integer,
    "TMMAX" double precision,
    "QTMMAX" integer,
    "TMMAXDAT" integer,
    "UNAB" integer,
    "QUNAB" integer,
    "UNABDAT" integer,
    "NBUN" integer,
    "UXAB" integer,
    "QUXAB" integer,
    "UXABDAT" integer,
    "NBUX" integer,
    "UMM" integer,
    "QUMM" integer,
    "NBUM" integer,
    "TSVM" double precision,
    "QTSVM" integer,
    "NBTSVM" integer,
    "FXIAB" double precision,
    "QFXIAB" integer,
    "DXIAB" integer,
    "QDXIAB" integer,
    "FXIDAT" integer,
    "NBJFF10" integer,
    "NBJFF16" integer,
    "NBJFF28" integer,
    "NBFXI" integer,
    "FXI3SAB" double precision,
    "QFXI3SAB" integer,
    "DXI3SAB" integer,
    "QDXI3SAB" integer,
    "FXI3SDAT" integer,
    "NBJFXI3S10" integer,
    "NBJFXI3S16" integer,
    "NBJFXI3S28" integer,
    "NBFXI3S" integer,
    "FXYAB" double precision,
    "QFXYAB" integer,
    "DXYAB" integer,
    "QDXYAB" integer,
    "FXYABDAT" integer,
    "NBJFXY8" integer,
    "NBJFXY10" integer,
    "NBJFXY15" integer,
    "NBFXY" integer,
    "FFM" double precision,
    "QFFM" integer,
    "NBFFM" integer,
    "INST" integer,
    "QINST" integer,
    "NBINST" integer,
    "NBSIGMA0" integer,
    "NBSIGMA20" integer,
    "NBSIGMA80" integer,
    "GLOT" integer,
    "QGLOT" integer,
    "NBGLOT" integer,
    "DIFT" integer,
    "QDIFT" integer,
    "NBDIFT" integer,
    "DIRT" integer,
    "QDIRT" integer,
    "NBDIRT" integer,
    "HNEIGEFTOT" integer,
    "QHNEIGEFTOT" integer,
    "HNEIGEFAB" integer,
    "QHNEIGEFAB" integer,
    "HNEIGEFDAT" integer,
    "NBHNEIGEF" integer,
    "NBJNEIG" integer,
    "NBJHNEIGEF1" integer,
    "NBJHNEIGEF5" integer,
    "NBJHNEIGEF10" integer,
    "NBJSOLNG" integer,
    "NEIGETOTM" integer,
    "QNEIGETOTM" integer,
    "NEIGETOTAB" integer,
    "QNEIGETOTAB" integer,
    "NEIGETOTABDAT" integer,
    "NBJNEIGETOT1" integer,
    "NBJNEIGETOT10" integer,
    "NBJNEIGETOT30" integer,
    "NBJGREL" integer,
    "NBJORAG" integer,
    "NBJBROU" integer
);
CREATE INDEX "Decadaire_AAAAMM_idx" ON public."Decadaire" USING btree ("AAAAMM");
CREATE INDEX "Decadaire_NUM_DECADE_idx" ON public."Decadaire" USING btree ("NUM_DECADE");
CREATE UNIQUE INDEX "Decadaire_pkey" ON public."Decadaire" USING btree ("NUM_POSTE", "AAAAMM", "NUM_DECADE");

CREATE TABLE "public"."DecadaireAgro" (
    "NUM_POSTE" character(8) NOT NULL,
    "NOM_USUEL" character varying(255) NOT NULL,
    "LAT" double precision NOT NULL,
    "LON" double precision NOT NULL,
    "ALTI" double precision NOT NULL,
    "AAAAMM" timestamp(3) without time zone NOT NULL,
    "NUM_DECADE" integer NOT NULL,
    "RR" double precision,
    "CRR" integer,
    "TN" double precision,
    "CTN" integer,
    "TX" double precision,
    "CTX" integer,
    "FFM" double precision,
    "CFFM" integer,
    "TSVM" double precision,
    "CTSVM" integer,
    "INST" integer,
    "CINST" integer,
    "GLOT" integer,
    "CGLOT" integer,
    "ETP" double precision
);
CREATE INDEX "DecadaireAgro_AAAAMM_idx" ON public."DecadaireAgro" USING btree ("AAAAMM");
CREATE INDEX "DecadaireAgro_NUM_DECADE_idx" ON public."DecadaireAgro" USING btree ("NUM_DECADE");
CREATE UNIQUE INDEX "DecadaireAgro_pkey" ON public."DecadaireAgro" USING btree ("NUM_POSTE", "AAAAMM", "NUM_DECADE");

CREATE TABLE "public"."Horaire" (
    "NUM_POSTE" character(8) NOT NULL,
    "NOM_USUEL" character varying(255) NOT NULL,
    "LAT" double precision NOT NULL,
    "LON" double precision NOT NULL,
    "ALTI" double precision NOT NULL,
    "AAAAMMJJHH" timestamp(3) without time zone NOT NULL,
    "RR1" double precision,
    "QRR1" integer,
    "DRR1" integer,
    "QDRR1" integer,
    "FF" double precision,
    "QFF" integer,
    "DD" integer,
    "QDD" integer,
    "FXY" double precision,
    "QFXY" integer,
    "DXY" integer,
    "QDXY" integer,
    "HXY" character(4),
    "QHXY" integer,
    "FXI" double precision,
    "QFXI" integer,
    "DXI" integer,
    "QDXI" integer,
    "HXI" character(4),
    "QHXI" integer,
    "FF2" double precision,
    "QFF2" integer,
    "DD2" integer,
    "QDD2" integer,
    "FXI2" double precision,
    "QFXI2" integer,
    "DXI2" integer,
    "QDXI2" integer,
    "HXI2" character(4),
    "QHXI2" integer,
    "FXI3S" double precision,
    "QFXI3S" integer,
    "DXI3S" integer,
    "QDXI3S" integer,
    "HFXI3S" character(4),
    "QHFXI3S" integer,
    "T" double precision,
    "QT" integer,
    "TD" double precision,
    "QTD" integer,
    "TN" double precision,
    "QTN" integer,
    "HTN" character(4),
    "QHTN" integer,
    "TX" double precision,
    "QTX" integer,
    "HTX" character(4),
    "QHTX" integer,
    "DG" integer,
    "QDG" integer,
    "T10" double precision,
    "QT10" integer,
    "T20" double precision,
    "QT20" integer,
    "T50" double precision,
    "QT50" integer,
    "T100" double precision,
    "QT100" integer,
    "TNSOL" double precision,
    "QTNSOL" integer,
    "TN50" double precision,
    "QTN50" integer,
    "TCHAUSSEE" double precision,
    "QTCHAUSSEE" integer,
    "DHUMEC" integer,
    "QDHUMEC" integer,
    "U" integer,
    "QU" integer,
    "UN" integer,
    "QUN" integer,
    "HUN" character(4),
    "QHUN" integer,
    "UX" integer,
    "QUX" integer,
    "HUX" character(4),
    "QHUX" integer,
    "DHUMI40" integer,
    "QDHUMI40" integer,
    "DHUMI80" integer,
    "QDHUMI80" integer,
    "TSV" double precision,
    "QTSV" integer,
    "PMER" double precision,
    "QPMER" integer,
    "PSTAT" double precision,
    "QPSTAT" integer,
    "PMERMIN" double precision,
    "QPMERMIN" integer,
    "GEOP" integer,
    "QGEOP" integer,
    "N" integer,
    "QN" integer,
    "NBAS" integer,
    "QNBAS" integer,
    "CL" text,
    "QCL" integer,
    "CM" text,
    "QCM" integer,
    "CH" text,
    "QCH" integer,
    "N1" integer,
    "QN1" integer,
    "C1" text,
    "QC1" integer,
    "B1" integer,
    "QB1" integer,
    "N2" integer,
    "QN2" integer,
    "C2" text,
    "QC2" integer,
    "B2" integer,
    "QB2" integer,
    "N3" integer,
    "QN3" integer,
    "C3" text,
    "QC3" integer,
    "B3" integer,
    "QB3" integer,
    "N4" integer,
    "QN4" integer,
    "C4" text,
    "QC4" integer,
    "B4" integer,
    "QB4" integer,
    "VV" integer,
    "QVV" integer,
    "DVV200" integer,
    "QDVV200" integer,
    "WW" character(2),
    "QWW" integer,
    "W1" character(2),
    "QW1" integer,
    "W2" character(2),
    "QW2" integer,
    "SOL" integer,
    "QSOL" integer,
    "SOLNG" integer,
    "QSOLNG" integer,
    "TMER" double precision,
    "QTMER" integer,
    "VVMER" integer,
    "QVVMER" integer,
    "ETATMER" integer,
    "QETATMER" integer,
    "DIRHOULE" integer,
    "QDIRHOULE" integer,
    "HVAGUE" double precision,
    "QHVAGUE" integer,
    "PVAGUE" double precision,
    "QPVAGUE" integer,
    "HNEIGEF" integer,
    "QHNEIGEF" integer,
    "NEIGETOT" integer,
    "QNEIGETOT" integer,
    "TSNEIGE" double precision,
    "QTSNEIGE" integer,
    "TUBENEIGE" integer,
    "QTUBENEIGE" integer,
    "HNEIGEFI3" integer,
    "QHNEIGEFI3" integer,
    "HNEIGEFI1" integer,
    "QHNEIGEFI1" integer,
    "ESNEIGE" integer,
    "QESNEIGE" integer,
    "CHARGENEIGE" integer,
    "QCHARGENEIGE" integer,
    "GLO" integer,
    "QGLO" integer,
    "GLO2" integer,
    "QGLO2" integer,
    "DIR" integer,
    "QDIR" integer,
    "DIR2" integer,
    "QDIR2" integer,
    "DIF" integer,
    "QDIF" integer,
    "DIF2" integer,
    "QDIF2" integer,
    "UV" double precision,
    "QUV" integer,
    "UV2" double precision,
    "QUV2" integer,
    "UV_INDICE" integer,
    "QUV_INDICE" integer,
    "INFRAR" integer,
    "QINFRAR" integer,
    "INFRAR2" integer,
    "QINFRAR2" integer,
    "INS" integer,
    "QINS" integer,
    "INS2" integer,
    "QINS2" integer,
    "TLAGON" double precision,
    "QTLAGON" integer,
    "TVEGETAUX" double precision,
    "QTVEGETAUX" integer,
    "ECOULEMENT" double precision,
    "QECOULEMENT" integer
);
CREATE INDEX "Horaire_AAAAMMJJHH_idx" ON public."Horaire" USING btree ("AAAAMMJJHH");
CREATE UNIQUE INDEX "Horaire_pkey" ON public."Horaire" USING btree ("NUM_POSTE", "AAAAMMJJHH");
-- hypertable: SELECT create_hypertable('public."Horaire"', by_range('AAAAMMJJHH', INTERVAL '31 days, 0:00:00'));

CREATE TABLE "public"."HoraireTempsReel" (
    "geo_id_insee" character(8) NOT NULL,
    "lat" double precision NOT NULL,
    "lon" double precision NOT NULL,
    "reference_time" timestamp(3) without time zone NOT NULL,
    "insert_time" timestamp(3) without time zone NOT NULL,
    "validity_time" timestamp(3) without time zone NOT NULL,
    "t" double precision,
    "td" double precision,
    "tx" double precision,
    "tn" double precision,
    "u" integer,
    "ux" integer,
    "un" integer,
    "dd" integer,
    "ff" double precision,
    "dxy" integer,
    "fxy" double precision,
    "dxi" integer,
    "fxi" double precision,
    "rr1" double precision,
    "t_10" double precision,
    "t_20" double precision,
    "t_50" double precision,
    "t_100" double precision,
    "vv" integer,
    "etat_sol" integer,
    "sss" double precision,
    "n" integer,
    "insolh" double precision,
    "ray_glo01" double precision,
    "pres" double precision,
    "pmer" double precision
);
CREATE UNIQUE INDEX "HoraireTempsReel_pkey" ON public."HoraireTempsReel" USING btree (geo_id_insee, validity_time);
CREATE INDEX "HoraireTempsReel_validity_time_idx" ON public."HoraireTempsReel" USING btree (validity_time);
-- hypertable: SELECT create_hypertable('public."HoraireTempsReel"', by_range('validity_time', INTERVAL '31 days, 0:00:00'));

CREATE TABLE "public"."InformationStation" (
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "id" character(8) NOT NULL,
    "nom" text NOT NULL,
    "lieuDit" text,
    "bassin" text NOT NULL,
    "dateDebut" timestamp(3) without time zone NOT NULL,
    "dateFin" timestamp(3) without time zone
);
CREATE UNIQUE INDEX "InformationStation_pkey" ON public."InformationStation" USING btree (id);

CREATE TABLE "public"."Infrahoraire" (
    "NUM_POSTE" character(8) NOT NULL,
    "NOM_USUEL" character varying(255) NOT NULL,
    "LAT" double precision NOT NULL,
    "LON" double precision NOT NULL,
    "ALTI" double precision NOT NULL,
    "AAAAMMJJHHMN" timestamp(3) without time zone NOT NULL,
    "RR" double precision,
    "QRR" integer
);
CREATE INDEX "Infrahoraire_AAAAMMJJHHMN_idx" ON public."Infrahoraire" USING btree ("AAAAMMJJHHMN");
CREATE UNIQUE INDEX "Infrahoraire_pkey" ON public."Infrahoraire" USING btree ("NUM_POSTE", "AAAAMMJJHHMN");
-- hypertable: SELECT create_hypertable('public."Infrahoraire"', by_range('AAAAMMJJHHMN', INTERVAL '31 days, 0:00:00'));

CREATE TABLE "public"."InfrahoraireTempsReel" (
    "geo_id_insee" character(8) NOT NULL,
    "lat" double precision NOT NULL,
    "lon" double precision NOT NULL,
    "reference_time" timestamp(3) without time zone NOT NULL,
    "insert_time" timestamp(3) without time zone NOT NULL,
    "validity_time" timestamp(3) without time zone NOT NULL,
    "t" double precision,
    "td" double precision,
    "u" integer,
    "dd" integer,
    "ff" double precision,
    "dxi10" integer,
    "fxi10" double precision,
    "rr_per" double precision,
    "t_10" double precision,
    "t_20" double precision,
    "t_50" double precision,
    "t_100" double precision,
    "vv" integer,
    "etat_sol" integer,
    "sss" double precision,
    "n" integer,
    "insolh" double precision,
    "ray_glo01" double precision,
    "pres" double precision,
    "pmer" double precision
);
CREATE UNIQUE INDEX "InfrahoraireTempsReel_pkey" ON public."InfrahoraireTempsReel" USING btree (geo_id_insee, validity_time);
CREATE INDEX "InfrahoraireTempsReel_validity_time_idx" ON public."InfrahoraireTempsReel" USING btree (validity_time);
-- hypertable: SELECT create_hypertable('public."InfrahoraireTempsReel"', by_range('validity_time', INTERVAL '31 days, 0:00:00'));

CREATE TABLE "public"."Mensuelle" (
    "NUM_POSTE" character(8) NOT NULL,
    "NOM_USUEL" character varying(255) NOT NULL,
    "LAT" double precision NOT NULL,
    "LON" double precision NOT NULL,
    "ALTI" double precision NOT NULL,
    "AAAAMM" timestamp(3) without time zone NOT NULL,
    "RR" double precision,
    "QRR" integer,
    "NBRR" integer,
    "RR_ME" double precision,
    "RRAB" double precision,
    "QRRAB" integer,
    "RRABDAT" integer,
    "NBJRR1" integer,
    "NBJRR5" integer,
    "NBJRR10" integer,
    "NBJRR30" integer,
    "NBJRR50" integer,
    "NBJRR100" integer,
    "PMERM" double precision,
    "QPMERM" integer,
    "NBPMERM" integer,
    "PMERMINAB" double precision,
    "QPMERMINAB" integer,
    "PMERMINABDAT" integer,
    "TX" double precision,
    "QTX" integer,
    "NBTX" integer,
    "TX_ME" double precision,
    "TXAB" double precision,
    "QTXAB" integer,
    "TXDAT" integer,
    "TXMIN" double precision,
    "QTXMIN" integer,
    "TXMINDAT" integer,
    "NBJTX0" integer,
    "NBJTX25" integer,
    "NBJTX30" integer,
    "NBJTX35" integer,
    "NBJTXI20" integer,
    "NBJTXI27" integer,
    "NBJTXS32" integer,
    "TN" double precision,
    "QTN" integer,
    "NBTN" integer,
    "TN_ME" double precision,
    "TNAB" double precision,
    "QTNAB" integer,
    "TNDAT" integer,
    "TNMAX" double precision,
    "QTNMAX" integer,
    "TNMAXDAT" integer,
    "NBJTN5" integer,
    "NBJTN10" integer,
    "NBJTNI10" integer,
    "NBJTNI15" integer,
    "NBJTNI20" integer,
    "NBJTNS20" integer,
    "NBJTNS25" integer,
    "NBJGELEE" integer,
    "TAMPLIM" double precision,
    "QTAMPLIM" integer,
    "TAMPLIAB" double precision,
    "QTAMPLIAB" integer,
    "TAMPLIABDAT" integer,
    "NBTAMPLI" integer,
    "TM" double precision,
    "QTM" integer,
    "NBTM" integer,
    "TMM" double precision,
    "QTMM" integer,
    "NBTMM" integer,
    "NBJTMS24" integer,
    "TMMIN" double precision,
    "QTMMIN" integer,
    "TMMINDAT" integer,
    "TMMAX" double precision,
    "QTMMAX" integer,
    "TMMAXDAT" integer,
    "UNAB" integer,
    "QUNAB" integer,
    "UNABDAT" integer,
    "NBUN" integer,
    "UXAB" integer,
    "QUXAB" integer,
    "UXABDAT" integer,
    "NBUX" integer,
    "UMM" integer,
    "QUMM" integer,
    "NBUM" integer,
    "TSVM" double precision,
    "QTSVM" integer,
    "NBTSVM" integer,
    "ETP" double precision,
    "QETP" integer,
    "FXIAB" double precision,
    "QFXIAB" integer,
    "DXIAB" integer,
    "QDXIAB" integer,
    "FXIDAT" integer,
    "NBJFF10" integer,
    "NBJFF16" integer,
    "NBJFF28" integer,
    "NBFXI" integer,
    "FXI3SAB" double precision,
    "QFXI3SAB" integer,
    "DXI3SAB" integer,
    "QDXI3SAB" integer,
    "FXI3SDAT" integer,
    "NBJFXI3S10" integer,
    "NBJFXI3S16" integer,
    "NBJFXI3S28" integer,
    "NBFXI3S" integer,
    "FXYAB" double precision,
    "QFXYAB" integer,
    "DXYAB" integer,
    "QDXYAB" integer,
    "FXYABDAT" integer,
    "NBJFXY8" integer,
    "NBJFXY10" integer,
    "NBJFXY15" integer,
    "NBFXY" integer,
    "FFM" double precision,
    "QFFM" integer,
    "NBFFM" integer,
    "INST" integer,
    "QINST" integer,
    "NBINST" integer,
    "NBSIGMA0" integer,
    "NBSIGMA20" integer,
    "NBSIGMA80" integer,
    "GLOT" integer,
    "QGLOT" integer,
    "NBGLOT" integer,
    "DIFT" integer,
    "QDIFT" integer,
    "NBDIFT" integer,
    "DIRT" integer,
    "QDIRT" integer,
    "NBDIRT" integer,
    "HNEIGEFTOT" integer,
    "QHNEIGEFTOT" integer,
    "HNEIGEFAB" integer,
    "QHNEIGEFAB" integer,
    "HNEIGEFDAT" integer,
    "NBHNEIGEF" integer,
    "NBJNEIG" integer,
    "NBJHNEIGEF1" integer,
    "NBJHNEIGEF5" integer,
    "NBJHNEIGEF10" integer,
    "NBJSOLNG" integer,
    "NEIGETOTM" integer,
    "QNEIGETOTM" integer,
    "NEIGETOTAB" integer,
    "QNEIGETOTAB" integer,
    "NEIGETOTABDAT" integer,
    "NBJNEIGETOT1" integer,
    "NBJNEIGETOT10" integer,
    "NBJNEIGETOT30" integer,
    "NBJGREL" integer,
    "NBJORAG" integer,
    "NBJBROU" integer
);
CREATE INDEX "Mensuelle_AAAAMM_idx" ON public."Mensuelle" USING btree ("AAAAMM");
CREATE UNIQUE INDEX "Mensuelle_pkey" ON public."Mensuelle" USING btree ("NUM_POSTE", "AAAAMM");

CREATE TABLE "public"."Parametre" (
    "id" integer DEFAULT nextval('"Parametre_id_seq"'::regclass) NOT NULL,
    "nom" text NOT NULL,
    "dateDebut" timestamp(3) without time zone NOT NULL,
    "dateFin" timestamp(3) without time zone,
    "stationId" character(8) NOT NULL
);
CREATE UNIQUE INDEX "Parametre_pkey" ON public."Parametre" USING btree (id);

CREATE TABLE "public"."Position" (
    "id" integer DEFAULT nextval('"Position_id_seq"'::regclass) NOT NULL,
    "altitude" double precision NOT NULL,
    "latitude" double precision NOT NULL,
    "longitude" double precision NOT NULL,
    "dateDebut" timestamp(3) without time zone NOT NULL,
    "dateFin" timestamp(3) without time zone,
    "stationId" character(8) NOT NULL
);
CREATE UNIQUE INDEX "Position_pkey" ON public."Position" USING btree (id);

CREATE TABLE "public"."Producteur" (
    "id" integer DEFAULT nextval('"Producteur_id_seq"'::regclass) NOT NULL,
    "nom" text NOT NULL,
    "dateDebut" timestamp(3) without time zone NOT NULL,
    "dateFin" timestamp(3) without time zone,
    "stationId" character(8) NOT NULL
);
CREATE UNIQUE INDEX "Producteur_pkey" ON public."Producteur" USING btree (id);

CREATE TABLE "public"."Quotidienne" (
    "NUM_POSTE" character(8) NOT NULL,
    "NOM_USUEL" character varying(255) NOT NULL,
    "LAT" double precision NOT NULL,
    "LON" double precision NOT NULL,
    "ALTI" double precision NOT NULL,
    "AAAAMMJJ" timestamp(3) without time zone NOT NULL,
    "RR" double precision,
    "QRR" integer,
    "TN" double precision,
    "QTN" integer,
    "HTN" character(4),
    "QHTN" integer,
    "TX" double precision,
    "QTX" integer,
    "HTX" character(4),
    "QHTX" integer,
    "TM" double precision,
    "QTM" integer,
    "TNTXM" double precision,
    "QTNTXM" integer,
    "TAMPLI" double precision,
    "QTAMPLI" integer,
    "TNSOL" double precision,
    "QTNSOL" integer,
    "TN50" double precision,
    "QTN50" integer,
    "DG" integer,
    "QDG" integer,
    "FFM" double precision,
    "QFFM" integer,
    "FF2M" double precision,
    "QFF2M" integer,
    "FXY" double precision,
    "QFXY" integer,
    "DXY" integer,
    "QDXY" integer,
    "HXY" character(4),
    "QHXY" integer,
    "FXI" double precision,
    "QFXI" integer,
    "DXI" integer,
    "QDXI" integer,
    "HXI" character(4),
    "QHXI" integer,
    "FXI2" double precision,
    "QFXI2" integer,
    "DXI2" integer,
    "QDXI2" integer,
    "HXI2" character(4),
    "QHXI2" integer,
    "FXI3S" double precision,
    "QFXI3S" integer,
    "DXI3S" integer,
    "QDXI3S" integer,
    "HXI3S" character(4),
    "QHXI3S" integer,
    "DRR" integer,
    "QDRR" integer
);
CREATE INDEX "Quotidienne_AAAAMMJJ_idx" ON public."Quotidienne" USING btree ("AAAAMMJJ");
CREATE UNIQUE INDEX "Quotidienne_pkey" ON public."Quotidienne" USING btree ("NUM_POSTE", "AAAAMMJJ");

CREATE TABLE "public"."QuotidienneAutresParametres" (
    "NUM_POSTE" character(8) NOT NULL,
    "NOM_USUEL" character varying(255) NOT NULL,
    "LAT" double precision NOT NULL,
    "LON" double precision NOT NULL,
    "ALTI" double precision NOT NULL,
    "AAAAMMJJ" timestamp(3) without time zone NOT NULL,
    "DHUMEC" integer,
    "QDHUMEC" integer,
    "PMERM" double precision,
    "QPMERM" integer,
    "PMERMIN" double precision,
    "QPMERMIN" integer,
    "INST" integer,
    "QINST" integer,
    "GLOT" integer,
    "QGLOT" integer,
    "DIFT" integer,
    "QDIFT" integer,
    "DIRT" integer,
    "QDIRT" integer,
    "INFRART" integer,
    "QINFRART" integer,
    "UV" double precision,
    "QUV" integer,
    "UV_INDICEX" integer,
    "QUV_INDICEX" integer,
    "SIGMA" integer,
    "QSIGMA" integer,
    "UN" integer,
    "QUN" integer,
    "HUN" character(4),
    "QHUN" integer,
    "UX" integer,
    "QUX" integer,
    "HUX" character(4),
    "QHUX" integer,
    "UM" integer,
    "QUM" integer,
    "DHUMI40" integer,
    "QDHUMI40" integer,
    "DHUMI80" integer,
    "QDHUMI80" integer,
    "TSVM" double precision,
    "QTSVM" integer,
    "ETPMON" double precision,
    "QETPMON" integer,
    "ETPGRILLE" double precision,
    "QETPGRILLE" integer,
    "ECOULEMENTM" double precision,
    "QECOULEMENTM" integer,
    "HNEIGEF" integer,
    "QHNEIGEF" integer,
    "NEIGETOTX" integer,
    "QNEIGETOTX" integer,
    "NEIGETOT06" integer,
    "QNEIGETOT06" integer,
    "NEIG" boolean,
    "QNEIG" integer,
    "BROU" boolean,
    "QBROU" integer,
    "ORAG" boolean,
    "QORAG" integer,
    "GRESIL" boolean,
    "QGRESIL" integer,
    "GRELE" boolean,
    "QGRELE" integer,
    "ROSEE" boolean,
    "QROSEE" integer,
    "VERGLAS" boolean,
    "QVERGLAS" integer,
    "SOLNEIGE" boolean,
    "QSOLNEIGE" integer,
    "GELEE" boolean,
    "QGELEE" integer,
    "FUMEE" boolean,
    "QFUMEE" integer,
    "BRUME" boolean,
    "QBRUME" integer,
    "ECLAIR" boolean,
    "QECLAIR" integer,
    "NB300" integer,
    "QNB300" integer,
    "BA300" integer,
    "QBA300" integer,
    "TMERMIN" double precision,
    "QTMERMIN" integer,
    "TMERMAX" double precision,
    "QTMERMAX" integer
);
CREATE INDEX "QuotidienneAutresParametres_AAAAMMJJ_idx" ON public."QuotidienneAutresParametres" USING btree ("AAAAMMJJ");
CREATE UNIQUE INDEX "QuotidienneAutresParametres_pkey" ON public."QuotidienneAutresParametres" USING btree ("NUM_POSTE", "AAAAMMJJ");

CREATE TABLE "public"."SaveProgress" (
    "name" character varying(255) NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);
CREATE UNIQUE INDEX "SaveProgress_pkey" ON public."SaveProgress" USING btree (name);

CREATE TABLE "public"."Station" (
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "id" character(8) NOT NULL,
    "nom" text NOT NULL,
    "departement" integer NOT NULL,
    "frequence" character varying(15) NOT NULL,
    "posteOuvert" boolean NOT NULL,
    "typePoste" integer NOT NULL,
    "lon" double precision NOT NULL,
    "lat" double precision NOT NULL,
    "alt" double precision NOT NULL,
    "postePublic" boolean NOT NULL
);
CREATE INDEX "Station_lat_idx" ON public."Station" USING btree (lat);
CREATE INDEX "Station_lon_idx" ON public."Station" USING btree (lon);
CREATE UNIQUE INDEX "Station_pkey" ON public."Station" USING btree (id, frequence);

CREATE TABLE "public"."StationTempsReel" (
    "Id_station" character(8) NOT NULL,
    "Id_omm" character(5),
    "Nom_usuel" character varying(255) NOT NULL,
    "Latitude" double precision NOT NULL,
    "Longitude" double precision NOT NULL,
    "Altitude" integer NOT NULL,
    "Date_ouverture" timestamp(3) without time zone NOT NULL,
    "Pack" "Pack" NOT NULL
);
CREATE INDEX "StationTempsReel_Latitude_idx" ON public."StationTempsReel" USING btree ("Latitude");
CREATE INDEX "StationTempsReel_Longitude_idx" ON public."StationTempsReel" USING btree ("Longitude");
CREATE UNIQUE INDEX "StationTempsReel_pkey" ON public."StationTempsReel" USING btree ("Id_station");

CREATE TABLE "public"."TypePoste" (
    "id" integer DEFAULT nextval('"TypePoste_id_seq"'::regclass) NOT NULL,
    "type" integer NOT NULL,
    "dateDebut" timestamp(3) without time zone NOT NULL,
    "dateFin" timestamp(3) without time zone,
    "stationId" character(8) NOT NULL
);
CREATE UNIQUE INDEX "TypePoste_pkey" ON public."TypePoste" USING btree (id);

CREATE TABLE "public"."_prisma_migrations" (
    "id" character varying(36) NOT NULL,
    "checksum" character varying(64) NOT NULL,
    "finished_at" timestamp with time zone,
    "migration_name" character varying(255) NOT NULL,
    "logs" text,
    "rolled_back_at" timestamp with time zone,
    "started_at" timestamp with time zone DEFAULT now() NOT NULL,
    "applied_steps_count" integer DEFAULT 0 NOT NULL
);
CREATE UNIQUE INDEX _prisma_migrations_pkey ON public._prisma_migrations USING btree (id);

CREATE TABLE "public"."mv_records_battus_meta" (
    "cutoff_date" date NOT NULL
);

CREATE TABLE "public"."ommid" (
    "mfid" character(8) NOT NULL,
    "stid" character varying NOT NULL
);
CREATE UNIQUE INDEX ommid_pkey ON public.ommid USING btree (mfid);

CREATE TABLE "public"."ref_department_region" (
    "departement" integer NOT NULL,
    "region" text NOT NULL
);
CREATE UNIQUE INDEX ref_department_region_pkey ON public.ref_department_region USING btree (departement);

CREATE TABLE "public"."station_classe" (
    "station_code" character(8) NOT NULL,
    "classe" integer NOT NULL,
    "date_debut" timestamp(3) without time zone NOT NULL,
    "date_fin" timestamp(3) without time zone
);
CREATE UNIQUE INDEX "Station_classe_pkey" ON public.station_classe USING btree (station_code, date_debut);
CREATE INDEX "Station_date_debut_idx" ON public.station_classe USING btree (date_debut);
CREATE INDEX "Station_date_fin_idx" ON public.station_classe USING btree (date_fin);

CREATE TABLE "public"."station_creation_date" (
    "station_code" character(8) NOT NULL,
    "date_de_creation" timestamp(3) without time zone NOT NULL,
    "date_de_fermeture" timestamp(3) without time zone
);
CREATE UNIQUE INDEX "Station_creation_date_new_pkey" ON public.station_creation_date USING btree (station_code);
CREATE INDEX "Station_date_de_creation_new_idx" ON public.station_creation_date USING btree (date_de_creation);
CREATE INDEX "Station_date_de_fermeture_new_idx" ON public.station_creation_date USING btree (date_de_fermeture);

CREATE TABLE "public"."station_creation_date_bak" (
    "station_code" character(8),
    "date_de_creation" timestamp without time zone,
    "date_de_fermeture" timestamp without time zone
);


-- ===== Vues materialisees (rafraichies par Kestra) =====
CREATE MATERIALIZED VIEW "public"."mv_baseline_station_daily_mean_1991_2020" AS
 SELECT station_code,
    month,
    day,
    sample_count,
    baseline_mean_tntxm
   FROM v_baseline_station_daily_mean_1991_2020;
WITH NO DATA;
CREATE UNIQUE INDEX idx_mv_baseline_station_daily_mean ON public.mv_baseline_station_daily_mean_1991_2020 USING btree (station_code, month, day);

CREATE MATERIALIZED VIEW "public"."mv_first_temperature_date" AS
 SELECT station_code,
    first_temperature_date
   FROM v_first_temperature_date
  ORDER BY station_code;
WITH NO DATA;
CREATE UNIQUE INDEX mv_first_temperature_date_uq ON public.mv_first_temperature_date USING btree (station_code);

CREATE MATERIALIZED VIEW "public"."mv_itn_daily_1991_2020_real" AS
 SELECT date,
    year,
    month,
    day_of_month,
    is_fictive,
    itn
   FROM v_itn_daily_1991_2020_real
  ORDER BY date;
WITH NO DATA;
CREATE UNIQUE INDEX idx_mv_itn_daily_1991_2020_real_date ON public.mv_itn_daily_1991_2020_real USING btree (date);
CREATE INDEX idx_mv_itn_daily_1991_2020_real_month_day ON public.mv_itn_daily_1991_2020_real USING btree (month, day_of_month);
CREATE INDEX idx_mv_itn_daily_1991_2020_real_year ON public.mv_itn_daily_1991_2020_real USING btree (year);

CREATE MATERIALIZED VIEW "public"."mv_itn_daily_all_years" AS
 SELECT date,
    year,
    month,
    day_of_month,
    is_fictive,
    itn
   FROM v_itn_daily_all_years
  ORDER BY date;
WITH NO DATA;
CREATE UNIQUE INDEX idx_mv_itn_daily_all_years_date ON public.mv_itn_daily_all_years USING btree (date);
CREATE INDEX idx_mv_itn_daily_all_years_month_day ON public.mv_itn_daily_all_years USING btree (month, day_of_month);
CREATE INDEX idx_mv_itn_daily_all_years_year ON public.mv_itn_daily_all_years USING btree (year);

CREATE MATERIALIZED VIEW "public"."mv_mensuelle_realtime" AS
 SELECT station_code,
    date,
    tnn,
    tnn_date,
    txx,
    txx_date,
    tmm
   FROM v_mensuelle_realtime
  ORDER BY station_code, date;
WITH NO DATA;
CREATE UNIQUE INDEX mv_mensuelle_realtime_uq ON public.mv_mensuelle_realtime USING btree (station_code, date);

CREATE MATERIALIZED VIEW "public"."mv_quotidienne_realtime" AS
 SELECT station_code,
    date,
    tntxm,
    tn,
    tx
   FROM v_quotidienne_realtime;
WITH NO DATA;
CREATE UNIQUE INDEX mv_quotidienne_realtime_uq ON public.mv_quotidienne_realtime USING btree (station_code, date);

CREATE MATERIALIZED VIEW "public"."mv_quotidienne_tn" AS
 SELECT "NUM_POSTE" AS station_code,
    "AAAAMMJJ" AS date,
    EXTRACT(month FROM "AAAAMMJJ")::integer AS month,
    EXTRACT(day FROM "AAAAMMJJ")::integer AS day,
    "TN" AS tn
   FROM "Quotidienne" q
  WHERE "TN" IS NOT NULL;
WITH NO DATA;
CREATE INDEX idx_mv_tn_record ON public.mv_quotidienne_tn USING btree (station_code, month, day, date);

CREATE MATERIALIZED VIEW "public"."mv_quotidienne_tx" AS
 SELECT "NUM_POSTE" AS station_code,
    "AAAAMMJJ" AS date,
    EXTRACT(month FROM "AAAAMMJJ")::integer AS month,
    EXTRACT(day FROM "AAAAMMJJ")::integer AS day,
    "TX" AS tx
   FROM "Quotidienne" q
  WHERE "TX" IS NOT NULL;
WITH NO DATA;
CREATE INDEX idx_mv_tx_record ON public.mv_quotidienne_tx USING btree (station_code, month, day, date);

CREATE MATERIALIZED VIEW "public"."mv_record_event_max_history" AS
 SELECT station_code,
    date,
    month,
    day,
    tx AS record_value,
    prev_record AS previous_record_value
   FROM ( SELECT mv_quotidienne_tx.station_code,
            mv_quotidienne_tx.date,
            mv_quotidienne_tx.month,
            mv_quotidienne_tx.day,
            mv_quotidienne_tx.tx,
            max(mv_quotidienne_tx.tx) OVER (PARTITION BY mv_quotidienne_tx.station_code, mv_quotidienne_tx.month, mv_quotidienne_tx.day ORDER BY mv_quotidienne_tx.date ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) AS prev_record
           FROM mv_quotidienne_tx
          WHERE mv_quotidienne_tx.tx IS NOT NULL) sub
  WHERE prev_record IS NOT NULL AND tx > prev_record;
WITH NO DATA;

CREATE MATERIALIZED VIEW "public"."mv_record_event_min_history" AS
 SELECT station_code,
    date,
    month,
    day,
    tn AS record_value,
    prev_record AS previous_record_value
   FROM ( SELECT mv_quotidienne_tn.station_code,
            mv_quotidienne_tn.date,
            mv_quotidienne_tn.month,
            mv_quotidienne_tn.day,
            mv_quotidienne_tn.tn,
            min(mv_quotidienne_tn.tn) OVER (PARTITION BY mv_quotidienne_tn.station_code, mv_quotidienne_tn.month, mv_quotidienne_tn.day ORDER BY mv_quotidienne_tn.date ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) AS prev_record
           FROM mv_quotidienne_tn
          WHERE mv_quotidienne_tn.tn IS NOT NULL) sub
  WHERE prev_record IS NOT NULL AND tn < prev_record;
WITH NO DATA;
CREATE INDEX mv_record_event_min_history_date_idx ON public.mv_record_event_min_history USING btree (date);
CREATE INDEX mv_record_event_min_history_station_date_idx ON public.mv_record_event_min_history USING btree (station_code, date);

CREATE MATERIALIZED VIEW "public"."mv_records_absolus_par_mois" AS
 SELECT station_code,
    month,
    txx_max,
    txx_max_date,
    tnn_min,
    tnn_min_date
   FROM v_records_absolus_par_mois
  ORDER BY station_code, month;
WITH NO DATA;
CREATE UNIQUE INDEX mv_records_absolus_par_mois_uq ON public.mv_records_absolus_par_mois USING btree (station_code, month);

CREATE MATERIALIZED VIEW "public"."mv_records_battus" AS
 SELECT period_type,
    period_value,
    record_type,
    station_code,
    station_name,
    department,
    record_value,
    record_date
   FROM v_records_battus;
WITH NO DATA;
CREATE UNIQUE INDEX idx_uq_mv_records_battus_query ON public.mv_records_battus USING btree (record_type, period_type, period_value, station_code, record_date);
CREATE INDEX idx_mv_records_battus_query ON public.mv_records_battus USING btree (record_type, period_type, period_value);
CREATE INDEX idx_mv_records_battus_station ON public.mv_records_battus USING btree (station_code);


-- ===== Vues (logique climato) =====
CREATE VIEW "public"."v_baseline_station_daily_mean_1991_2020" AS
 WITH quotidienne_1991_2020 AS (
         SELECT "Quotidienne"."NUM_POSTE" AS station_code,
            "Quotidienne"."AAAAMMJJ" AS date,
            "Quotidienne"."TNTXM" AS tntxm
           FROM "Quotidienne"
          WHERE '1991-01-01 00:00:00'::timestamp without time zone <= "Quotidienne"."AAAAMMJJ" AND "Quotidienne"."AAAAMMJJ" < '2021-01-01 00:00:00'::timestamp without time zone AND "Quotidienne"."TNTXM" IS NOT NULL AND ("Quotidienne"."NUM_POSTE" IN ( SELECT v_station_deviation.station_code
                   FROM v_station_deviation))
        ), base AS (
         SELECT v.station_code,
            v.date,
            v.tntxm,
            EXTRACT(year FROM v.date)::integer AS year,
            EXTRACT(month FROM v.date)::integer AS month,
            EXTRACT(day FROM v.date)::integer AS day
           FROM quotidienne_1991_2020 v
        ), normal_days AS (
         SELECT b.station_code,
            b.year,
            b.month,
            b.day,
            b.tntxm AS daily_value
           FROM base b
          WHERE NOT (b.month = 2 AND b.day = 29)
        ), leap_feb29 AS (
         SELECT b.station_code,
            b.year,
            2 AS month,
            29 AS day,
            b.tntxm AS daily_value
           FROM base b
          WHERE b.month = 2 AND b.day = 29
        ), non_leap_feb29 AS (
         SELECT x.station_code,
            x.year,
            2 AS month,
            29 AS day,
                CASE
                    WHEN count(*) = 2 THEN avg(x.tntxm)
                    ELSE NULL::double precision
                END AS daily_value
           FROM ( SELECT base.station_code,
                    base.year,
                    base.tntxm
                   FROM base
                  WHERE base.month = 2 AND base.day = 28
                UNION ALL
                 SELECT base.station_code,
                    base.year,
                    base.tntxm
                   FROM base
                  WHERE base.month = 3 AND base.day = 1) x
          WHERE NOT ((x.year % 4) = 0 AND (x.year % 100) <> 0 OR (x.year % 400) = 0)
          GROUP BY x.station_code, x.year
        ), normalized_daily AS (
         SELECT normal_days.station_code,
            normal_days.year,
            normal_days.month,
            normal_days.day,
            normal_days.daily_value
           FROM normal_days
        UNION ALL
         SELECT leap_feb29.station_code,
            leap_feb29.year,
            leap_feb29.month,
            leap_feb29.day,
            leap_feb29.daily_value
           FROM leap_feb29
        UNION ALL
         SELECT non_leap_feb29.station_code,
            non_leap_feb29.year,
            non_leap_feb29.month,
            non_leap_feb29.day,
            non_leap_feb29.daily_value
           FROM non_leap_feb29
          WHERE non_leap_feb29.daily_value IS NOT NULL
        )
 SELECT station_code,
    month,
    day,
    count(daily_value) AS sample_count,
    round(avg(daily_value)::numeric, 2) AS baseline_mean_tntxm
   FROM normalized_daily nd
  GROUP BY station_code, month, day
 HAVING count(daily_value) >= 24;

CREATE VIEW "public"."v_first_temperature_date" AS
 SELECT "NUM_POSTE" AS station_code,
    min("AAAAMM") AS first_temperature_date
   FROM "Mensuelle"
  WHERE "TM" IS NOT NULL
  GROUP BY "NUM_POSTE";

CREATE VIEW "public"."v_itn_absolute_extremes_daily" AS
 SELECT month,
    day_of_month,
    min(itn) AS absolute_min,
    max(itn) AS absolute_max
   FROM v_itn_daily_all_years_with_feb29
  GROUP BY month, day_of_month;

CREATE VIEW "public"."v_itn_absolute_extremes_monthly" AS
 WITH monthly_itn AS (
         SELECT v_itn_daily_all_years_with_feb29.year,
            v_itn_daily_all_years_with_feb29.month,
            avg(v_itn_daily_all_years_with_feb29.itn) AS monthly_mean
           FROM v_itn_daily_all_years_with_feb29
          WHERE NOT v_itn_daily_all_years_with_feb29.is_fictive AND make_date(v_itn_daily_all_years_with_feb29.year, v_itn_daily_all_years_with_feb29.month, 1) < date_trunc('month'::text, now())
          GROUP BY v_itn_daily_all_years_with_feb29.year, v_itn_daily_all_years_with_feb29.month
        )
 SELECT month,
    min(monthly_mean) AS absolute_min,
    max(monthly_mean) AS absolute_max
   FROM monthly_itn
  GROUP BY month;

CREATE VIEW "public"."v_itn_absolute_extremes_yearly" AS
 WITH yearly_itn AS (
         SELECT v_itn_daily_all_years_with_feb29.year,
            avg(v_itn_daily_all_years_with_feb29.itn) AS yearly_mean
           FROM v_itn_daily_all_years_with_feb29
          WHERE NOT v_itn_daily_all_years_with_feb29.is_fictive AND v_itn_daily_all_years_with_feb29.year::numeric < EXTRACT(year FROM now())
          GROUP BY v_itn_daily_all_years_with_feb29.year
        )
 SELECT min(yearly_mean) AS absolute_min,
    max(yearly_mean) AS absolute_max
   FROM yearly_itn
 HAVING min(yearly_mean) IS NOT NULL AND max(yearly_mean) IS NOT NULL;

CREATE VIEW "public"."v_itn_baseline_daily_1991_2020" AS
 SELECT month,
    day_of_month,
    count(*)::integer AS sample_size,
    avg(itn) AS itn_mean,
    stddev_pop(itn) AS itn_stddev,
    percentile_cont(0.2::double precision) WITHIN GROUP (ORDER BY itn) AS itn_p20,
    percentile_cont(0.8::double precision) WITHIN GROUP (ORDER BY itn) AS itn_p80
   FROM v_itn_daily_1991_2020_with_feb29
  GROUP BY month, day_of_month;

CREATE VIEW "public"."v_itn_baseline_monthly_1991_2020" AS
 WITH monthly_series AS (
         SELECT v_itn_daily_1991_2020_with_feb29.year,
            v_itn_daily_1991_2020_with_feb29.month,
            avg(v_itn_daily_1991_2020_with_feb29.itn) AS monthly_itn
           FROM v_itn_daily_1991_2020_with_feb29
          GROUP BY v_itn_daily_1991_2020_with_feb29.year, v_itn_daily_1991_2020_with_feb29.month
        )
 SELECT month,
    count(*)::integer AS sample_size,
    avg(monthly_itn) AS itn_mean,
    stddev_pop(monthly_itn) AS itn_stddev,
    percentile_cont(0.2::double precision) WITHIN GROUP (ORDER BY monthly_itn) AS itn_p20,
    percentile_cont(0.8::double precision) WITHIN GROUP (ORDER BY monthly_itn) AS itn_p80
   FROM monthly_series
  GROUP BY month;

CREATE VIEW "public"."v_itn_baseline_yearly_1991_2020" AS
 WITH yearly_series AS (
         SELECT v_itn_daily_1991_2020_with_feb29.year,
            avg(v_itn_daily_1991_2020_with_feb29.itn) AS yearly_itn
           FROM v_itn_daily_1991_2020_with_feb29
          GROUP BY v_itn_daily_1991_2020_with_feb29.year
        )
 SELECT count(*)::integer AS sample_size,
    avg(yearly_itn) AS itn_mean,
    stddev_pop(yearly_itn) AS itn_stddev,
    percentile_cont(0.2::double precision) WITHIN GROUP (ORDER BY yearly_itn) AS itn_p20,
    percentile_cont(0.8::double precision) WITHIN GROUP (ORDER BY yearly_itn) AS itn_p80
   FROM yearly_series;

CREATE VIEW "public"."v_itn_daily_1991_2020_real" AS
 WITH quotidienne_1991_2020 AS (
         SELECT "Quotidienne"."NUM_POSTE" AS station_code,
            "Quotidienne"."AAAAMMJJ" AS date,
            "Quotidienne"."TNTXM" AS tntxm
           FROM "Quotidienne"
          WHERE '1991-01-01 00:00:00'::timestamp without time zone <= "Quotidienne"."AAAAMMJJ" AND "Quotidienne"."AAAAMMJJ" < '2021-01-01 00:00:00'::timestamp without time zone AND "Quotidienne"."TNTXM" IS NOT NULL AND ("Quotidienne"."NUM_POSTE" IN ( SELECT v_station_itn.station_code
                   FROM v_station_itn))
        ), source AS (
         SELECT q.station_code,
            q.date,
            q.tntxm
           FROM quotidienne_1991_2020 q
        ), normalized AS (
         SELECT source.station_code,
            source.date,
            source.tntxm
           FROM source
          WHERE NOT source.station_code::text =
                CASE
                    WHEN source.date < '2012-05-08 00:00:00'::timestamp without time zone THEN '51449002'::text
                    ELSE '51183001'::text
                END
        ), distinct_dates AS (
         SELECT DISTINCT normalized.date
           FROM normalized
        ), stations_without_reims AS (
         SELECT v_station_itn.station_code
           FROM v_station_itn
          WHERE v_station_itn.station_code <> ALL (ARRAY['51183001'::bpchar, '51449002'::bpchar])
        ), expected_by_day AS (
         SELECT d.date,
            swr.station_code
           FROM distinct_dates d
             CROSS JOIN stations_without_reims swr
        UNION ALL
         SELECT d.date,
                CASE
                    WHEN d.date < '2012-05-08 00:00:00'::timestamp without time zone THEN '51183001'::text
                    ELSE '51449002'::text
                END AS station_code
           FROM distinct_dates d
        ), present AS (
         SELECT DISTINCT normalized.date,
            normalized.station_code
           FROM normalized
        ), valid_days AS (
         SELECT d.date
           FROM distinct_dates d
             LEFT JOIN ( SELECT e.date,
                    count(*) AS missing_count
                   FROM expected_by_day e
                     LEFT JOIN present p ON p.date = e.date AND p.station_code = e.station_code
                  WHERE p.station_code IS NULL
                  GROUP BY e.date) m ON m.date = d.date
             LEFT JOIN ( SELECT p.date,
                    count(*) AS unexpected_count
                   FROM present p
                     LEFT JOIN expected_by_day e ON e.date = p.date AND e.station_code = p.station_code
                  WHERE e.station_code IS NULL
                  GROUP BY p.date) u ON u.date = d.date
             LEFT JOIN ( SELECT present.date,
                    count(*) AS normalized_station_count
                   FROM present
                  GROUP BY present.date) c ON c.date = d.date
          WHERE COALESCE(m.missing_count, 0::bigint) = 0 AND COALESCE(u.unexpected_count, 0::bigint) = 0 AND COALESCE(c.normalized_station_count, 0::bigint) = 30
        )
 SELECT n.date,
    EXTRACT(year FROM n.date)::integer AS year,
    EXTRACT(month FROM n.date)::integer AS month,
    EXTRACT(day FROM n.date)::integer AS day_of_month,
    false AS is_fictive,
    avg(n.tntxm) AS itn
   FROM normalized n
     JOIN valid_days v ON v.date = n.date
  GROUP BY n.date;

CREATE VIEW "public"."v_itn_daily_1991_2020_with_feb29" AS
 WITH feb29_fictive AS (
         SELECT NULL::date AS date,
            feb28.year,
            2 AS month,
            29 AS day_of_month,
            true AS is_fictive,
            (feb28.itn + mar01.itn) / 2.0::double precision AS itn
           FROM mv_itn_daily_1991_2020_real feb28
             JOIN mv_itn_daily_1991_2020_real mar01 ON mar01.year = feb28.year AND mar01.month = 3 AND mar01.day_of_month = 1
          WHERE feb28.month = 2 AND feb28.day_of_month = 28 AND NOT ((feb28.year % 4) = 0 AND (feb28.year % 100) <> 0 OR (feb28.year % 400) = 0)
        )
 SELECT date,
    year,
    month,
    day_of_month,
    is_fictive,
    itn
   FROM ( SELECT mv_itn_daily_1991_2020_real.date,
            mv_itn_daily_1991_2020_real.year,
            mv_itn_daily_1991_2020_real.month,
            mv_itn_daily_1991_2020_real.day_of_month,
            mv_itn_daily_1991_2020_real.is_fictive,
            mv_itn_daily_1991_2020_real.itn
           FROM mv_itn_daily_1991_2020_real
        UNION ALL
         SELECT feb29_fictive.date,
            feb29_fictive.year,
            feb29_fictive.month,
            feb29_fictive.day_of_month,
            feb29_fictive.is_fictive,
            feb29_fictive.itn
           FROM feb29_fictive) x;

CREATE VIEW "public"."v_itn_daily_all_years" AS
 WITH source AS (
         SELECT q.station_code,
            q.date,
            q.tntxm
           FROM v_quotidienne q
          WHERE (q.station_code IN ( SELECT v_station_itn.station_code
                   FROM v_station_itn)) AND q.date >= '1947-01-01 00:00:00'::timestamp without time zone
        ), normalized AS (
         SELECT source.station_code,
            source.date,
            source.tntxm
           FROM source
          WHERE NOT source.station_code::text =
                CASE
                    WHEN source.date < '2012-05-08 00:00:00'::timestamp without time zone THEN '51449002'::text
                    ELSE '51183001'::text
                END
        )
 SELECT date,
    EXTRACT(year FROM date)::integer AS year,
    EXTRACT(month FROM date)::integer AS month,
    EXTRACT(day FROM date)::integer AS day_of_month,
    false AS is_fictive,
    avg(tntxm) AS itn
   FROM normalized n
  GROUP BY date
 HAVING count(DISTINCT station_code) >= 29;

CREATE VIEW "public"."v_itn_daily_all_years_with_feb29" AS
 WITH feb29_fictive AS (
         SELECT NULL::date AS date,
            feb28.year,
            2 AS month,
            29 AS day_of_month,
            true AS is_fictive,
            (feb28.itn + mar01.itn) / 2.0::double precision AS itn
           FROM mv_itn_daily_all_years feb28
             JOIN mv_itn_daily_all_years mar01 ON mar01.year = feb28.year AND mar01.month = 3 AND mar01.day_of_month = 1
          WHERE feb28.month = 2 AND feb28.day_of_month = 28 AND NOT ((feb28.year % 4) = 0 AND (feb28.year % 100) <> 0 OR (feb28.year % 400) = 0)
        )
 SELECT date,
    year,
    month,
    day_of_month,
    is_fictive,
    itn
   FROM ( SELECT mv_itn_daily_all_years.date,
            mv_itn_daily_all_years.year,
            mv_itn_daily_all_years.month,
            mv_itn_daily_all_years.day_of_month,
            mv_itn_daily_all_years.is_fictive,
            mv_itn_daily_all_years.itn
           FROM mv_itn_daily_all_years
        UNION ALL
         SELECT feb29_fictive.date,
            feb29_fictive.year,
            feb29_fictive.month,
            feb29_fictive.day_of_month,
            feb29_fictive.is_fictive,
            feb29_fictive.itn
           FROM feb29_fictive) x;

CREATE VIEW "public"."v_mensuelle" AS
 WITH mensuelle_climato AS (
         SELECT "Mensuelle"."NUM_POSTE" AS station_code,
            "Mensuelle"."AAAAMM" AS date,
            "Mensuelle"."TNAB" AS tnn,
            ("Mensuelle"."AAAAMM" + ("Mensuelle"."TNDAT" - 1)::double precision * '1 day'::interval)::timestamp(3) without time zone AS tnn_date,
            "Mensuelle"."TXAB" AS txx,
            ("Mensuelle"."AAAAMM" + ("Mensuelle"."TXDAT" - 1)::double precision * '1 day'::interval)::timestamp(3) without time zone AS txx_date,
            "Mensuelle"."TM" AS tmm
           FROM "Mensuelle"
          WHERE "Mensuelle"."AAAAMM" < (date_trunc('month'::text, now()) - '2 mons'::interval)
        ), combined_mensuelle AS (
         SELECT mv_mensuelle_realtime.station_code,
            mv_mensuelle_realtime.date,
            mv_mensuelle_realtime.tnn,
            mv_mensuelle_realtime.tnn_date,
            mv_mensuelle_realtime.txx,
            mv_mensuelle_realtime.txx_date,
            mv_mensuelle_realtime.tmm
           FROM mv_mensuelle_realtime
        UNION ALL
         SELECT mensuelle_climato.station_code,
            mensuelle_climato.date,
            mensuelle_climato.tnn,
            mensuelle_climato.tnn_date,
            mensuelle_climato.txx,
            mensuelle_climato.txx_date,
            mensuelle_climato.tmm
           FROM mensuelle_climato
        )
 SELECT station_code,
    date,
    tnn,
    tnn_date,
    txx,
    txx_date,
    tmm
   FROM combined_mensuelle;

CREATE VIEW "public"."v_mensuelle_realtime" AS
 WITH ranked AS (
         SELECT v_quotidienne.station_code,
            date_trunc('month'::text, v_quotidienne.date) AS month_date,
            v_quotidienne.date AS daily_date,
            v_quotidienne.tn,
            v_quotidienne.tx,
            v_quotidienne.tntxm,
            row_number() OVER (PARTITION BY v_quotidienne.station_code, (date_trunc('month'::text, v_quotidienne.date)) ORDER BY v_quotidienne.tn, v_quotidienne.date) AS rn_tn_min,
            row_number() OVER (PARTITION BY v_quotidienne.station_code, (date_trunc('month'::text, v_quotidienne.date)) ORDER BY v_quotidienne.tx DESC NULLS LAST, v_quotidienne.date) AS rn_tx_max
           FROM v_quotidienne
          WHERE v_quotidienne.date >= (date_trunc('month'::text, now()) - '2 mons'::interval)
        )
 SELECT station_code,
    month_date AS date,
    min(tn) AS tnn,
    max(
        CASE
            WHEN rn_tn_min = 1 AND tn IS NOT NULL THEN daily_date
            ELSE NULL::timestamp without time zone
        END) AS tnn_date,
    max(tx) AS txx,
    max(
        CASE
            WHEN rn_tx_max = 1 AND tx IS NOT NULL THEN daily_date
            ELSE NULL::timestamp without time zone
        END) AS txx_date,
    round(avg(tntxm)::numeric, 1) AS tmm
   FROM ranked
  GROUP BY station_code, month_date;

CREATE VIEW "public"."v_quotidienne" AS
 WITH quotidienne AS (
         SELECT "Quotidienne"."NUM_POSTE" AS station_code,
            "Quotidienne"."AAAAMMJJ" AS date,
            "Quotidienne"."TNTXM" AS tntxm,
            "Quotidienne"."TN" AS tn,
            "Quotidienne"."TX" AS tx
           FROM "Quotidienne"
          WHERE "Quotidienne"."AAAAMMJJ" < (date_trunc('day'::text, now()) - '3 days'::interval)
        ), combined_quotidienne AS (
         SELECT mv_quotidienne_realtime.station_code,
            mv_quotidienne_realtime.date,
            mv_quotidienne_realtime.tntxm,
            mv_quotidienne_realtime.tn,
            mv_quotidienne_realtime.tx
           FROM mv_quotidienne_realtime
        UNION ALL
         SELECT quotidienne.station_code,
            quotidienne.date,
            quotidienne.tntxm,
            quotidienne.tn,
            quotidienne.tx
           FROM quotidienne
        )
 SELECT station_code,
    date,
    tntxm,
    tn,
    tx
   FROM combined_quotidienne
  WHERE tntxm IS NOT NULL;

CREATE VIEW "public"."v_quotidienne_deviation" AS
 SELECT station_code,
    date,
    tntxm,
    tn,
    tx
   FROM v_quotidienne
  WHERE (station_code IN ( SELECT v_station_deviation.station_code
           FROM v_station_deviation));

CREATE VIEW "public"."v_quotidienne_realtime" AS
 WITH horaire_from_infrahoraire AS (
         SELECT "InfrahoraireTempsReel".geo_id_insee AS station_id,
            date_trunc('hour'::text, "InfrahoraireTempsReel".validity_time - '00:00:01'::interval) + '01:00:00'::interval AS "timestamp",
            last("InfrahoraireTempsReel".t, "InfrahoraireTempsReel".validity_time) AS t,
            min("InfrahoraireTempsReel".t) AS tn,
            max("InfrahoraireTempsReel".t) AS tx
           FROM "InfrahoraireTempsReel"
          WHERE "InfrahoraireTempsReel".validity_time > (date_trunc('hour'::text, now()) - '03:00:00'::interval)
          GROUP BY "InfrahoraireTempsReel".geo_id_insee, (date_trunc('hour'::text, "InfrahoraireTempsReel".validity_time - '00:00:01'::interval) + '01:00:00'::interval)
        ), horaire_temps_reel AS (
         SELECT "HoraireTempsReel".geo_id_insee AS station_id,
            "HoraireTempsReel".validity_time AS "timestamp",
            "HoraireTempsReel".t,
            "HoraireTempsReel".tn,
            "HoraireTempsReel".tx
           FROM "HoraireTempsReel"
          WHERE (date_trunc('hour'::text, now()) - '36:00:00'::interval) <= "HoraireTempsReel".validity_time AND "HoraireTempsReel".validity_time <= (date_trunc('hour'::text, now()) - '03:00:00'::interval)
        ), horaire AS (
         SELECT "Horaire"."NUM_POSTE" AS station_id,
            "Horaire"."AAAAMMJJHH" AS "timestamp",
            "Horaire"."T" AS t,
            "Horaire"."TN" AS tn,
            "Horaire"."TX" AS tx
           FROM "Horaire"
          WHERE (date_trunc('day'::text, now()) - '4 days'::interval) <= "Horaire"."AAAAMMJJHH" AND "Horaire"."AAAAMMJJHH" < (date_trunc('hour'::text, now()) - '36:00:00'::interval)
        ), combined_horaire AS (
         SELECT horaire_from_infrahoraire.station_id,
            horaire_from_infrahoraire."timestamp",
            horaire_from_infrahoraire.t,
            horaire_from_infrahoraire.tn,
            horaire_from_infrahoraire.tx
           FROM horaire_from_infrahoraire
        UNION ALL
         SELECT horaire_temps_reel.station_id,
            horaire_temps_reel."timestamp",
            horaire_temps_reel.t,
            horaire_temps_reel.tn,
            horaire_temps_reel.tx
           FROM horaire_temps_reel
        UNION ALL
         SELECT horaire.station_id,
            horaire."timestamp",
            horaire.t,
            horaire.tn,
            horaire.tx
           FROM horaire
        ), tn_quotidienne_temps_reel AS (
         SELECT combined_horaire.station_id,
            date_trunc('day'::text, combined_horaire."timestamp" - '18:00:00'::interval - '00:00:01'::interval) + '1 day'::interval AS "timestamp",
            min(combined_horaire.tn) AS tn
           FROM combined_horaire
          WHERE combined_horaire."timestamp" > (date_trunc('day'::text, now()) - '4 days'::interval + '18:00:00'::interval)
          GROUP BY combined_horaire.station_id, (date_trunc('day'::text, combined_horaire."timestamp" - '18:00:00'::interval - '00:00:01'::interval) + '1 day'::interval)
        ), tx_quotidienne_temps_reel AS (
         SELECT combined_horaire.station_id,
            date_trunc('day'::text, combined_horaire."timestamp" - '06:00:00'::interval - '00:00:01'::interval) AS "timestamp",
            max(combined_horaire.tx) AS tx
           FROM combined_horaire
          WHERE combined_horaire."timestamp" > (date_trunc('day'::text, now()) - '3 days'::interval + '06:00:00'::interval)
          GROUP BY combined_horaire.station_id, (date_trunc('day'::text, combined_horaire."timestamp" - '06:00:00'::interval - '00:00:01'::interval))
        ), tn_tx_quotidienne_temps_reel AS (
         SELECT tn_quotidienne_temps_reel.station_id,
            tn_quotidienne_temps_reel."timestamp",
            tn_quotidienne_temps_reel.tn,
            NULL::numeric AS tx
           FROM tn_quotidienne_temps_reel
        UNION ALL
         SELECT tx_quotidienne_temps_reel.station_id,
            tx_quotidienne_temps_reel."timestamp",
            NULL::numeric AS tn,
            tx_quotidienne_temps_reel.tx
           FROM tx_quotidienne_temps_reel
        ), quotidienne_temps_reel AS (
         SELECT tn_tx_quotidienne_temps_reel.station_id,
            tn_tx_quotidienne_temps_reel."timestamp",
            (min(tn_tx_quotidienne_temps_reel.tn) + max(tn_tx_quotidienne_temps_reel.tx)) / 2.0::double precision AS tntxm,
            min(tn_tx_quotidienne_temps_reel.tn) AS tn,
            max(tn_tx_quotidienne_temps_reel.tx) AS tx
           FROM tn_tx_quotidienne_temps_reel
          WHERE tn_tx_quotidienne_temps_reel."timestamp" >= (date_trunc('day'::text, now()) - '3 days'::interval)
          GROUP BY tn_tx_quotidienne_temps_reel.station_id, tn_tx_quotidienne_temps_reel."timestamp"
        )
 SELECT station_id AS station_code,
    "timestamp"::timestamp(3) without time zone AS date,
    tntxm,
    tn,
    tx
   FROM quotidienne_temps_reel
  WHERE tntxm IS NOT NULL;

CREATE VIEW "public"."v_records_absolus" AS
 WITH ranked AS (
         SELECT v_records_absolus_par_saison.station_code,
            v_records_absolus_par_saison.txx_max_date,
            v_records_absolus_par_saison.tnn_min_date,
            v_records_absolus_par_saison.txx_max,
            v_records_absolus_par_saison.tnn_min,
            row_number() OVER (PARTITION BY v_records_absolus_par_saison.station_code ORDER BY v_records_absolus_par_saison.txx_max DESC NULLS LAST, v_records_absolus_par_saison.txx_max_date) AS rn_txx_max,
            row_number() OVER (PARTITION BY v_records_absolus_par_saison.station_code ORDER BY v_records_absolus_par_saison.tnn_min, v_records_absolus_par_saison.tnn_min_date) AS rn_tnn_min
           FROM v_records_absolus_par_saison
        )
 SELECT station_code,
    max(
        CASE
            WHEN rn_txx_max = 1 THEN txx_max
            ELSE NULL::double precision
        END) AS txx_max,
    max(
        CASE
            WHEN rn_txx_max = 1 THEN txx_max_date
            ELSE NULL::timestamp without time zone
        END) AS txx_max_date,
    max(
        CASE
            WHEN rn_tnn_min = 1 THEN tnn_min
            ELSE NULL::double precision
        END) AS tnn_min,
    max(
        CASE
            WHEN rn_tnn_min = 1 THEN tnn_min_date
            ELSE NULL::timestamp without time zone
        END) AS tnn_min_date
   FROM ranked
  GROUP BY station_code;

CREATE VIEW "public"."v_records_absolus_par_mois" AS
 WITH ranked AS (
         SELECT m.station_code,
            m.date,
            m.txx,
            m.txx_date,
            m.tnn,
            m.tnn_date,
            row_number() OVER (PARTITION BY m.station_code, (EXTRACT(month FROM m.date)::integer) ORDER BY m.txx DESC NULLS LAST, m.txx_date) AS rn_txx_max,
            row_number() OVER (PARTITION BY m.station_code, (EXTRACT(month FROM m.date)::integer) ORDER BY m.tnn, m.tnn_date) AS rn_tnn_min
           FROM v_mensuelle m
             JOIN v_station_records s ON m.station_code = s.station_code
          WHERE m.txx IS NOT NULL OR m.tnn IS NOT NULL
        )
 SELECT station_code,
    EXTRACT(month FROM date)::integer AS month,
    max(
        CASE
            WHEN rn_txx_max = 1 THEN txx
            ELSE NULL::double precision
        END) AS txx_max,
    max(
        CASE
            WHEN rn_txx_max = 1 THEN txx_date
            ELSE NULL::timestamp without time zone
        END) AS txx_max_date,
    max(
        CASE
            WHEN rn_tnn_min = 1 THEN tnn
            ELSE NULL::double precision
        END) AS tnn_min,
    max(
        CASE
            WHEN rn_tnn_min = 1 THEN tnn_date
            ELSE NULL::timestamp without time zone
        END) AS tnn_min_date
   FROM ranked
  GROUP BY station_code, (EXTRACT(month FROM date)::integer);

CREATE VIEW "public"."v_records_absolus_par_saison" AS
 WITH base AS (
         SELECT m.station_code,
            m.txx_max_date,
            m.tnn_min_date,
            m.txx_max,
            m.tnn_min,
                CASE
                    WHEN m.month = ANY (ARRAY[12, 1, 2]) THEN 1
                    WHEN m.month = ANY (ARRAY[3, 4, 5]) THEN 2
                    WHEN m.month = ANY (ARRAY[6, 7, 8]) THEN 3
                    ELSE 4
                END AS season_id
           FROM mv_records_absolus_par_mois m
        ), ranked AS (
         SELECT base.station_code,
            base.txx_max_date,
            base.tnn_min_date,
            base.txx_max,
            base.tnn_min,
            base.season_id,
            row_number() OVER (PARTITION BY base.station_code, base.season_id ORDER BY base.txx_max DESC NULLS LAST, base.txx_max_date) AS rn_txx_max,
            row_number() OVER (PARTITION BY base.station_code, base.season_id ORDER BY base.tnn_min, base.tnn_min_date) AS rn_tnn_min
           FROM base
        )
 SELECT station_code,
        CASE season_id
            WHEN 1 THEN 'winter'::text
            WHEN 2 THEN 'spring'::text
            WHEN 3 THEN 'summer'::text
            ELSE 'autumn'::text
        END AS season,
    max(
        CASE
            WHEN rn_txx_max = 1 THEN txx_max
            ELSE NULL::double precision
        END) AS txx_max,
    max(
        CASE
            WHEN rn_txx_max = 1 THEN txx_max_date
            ELSE NULL::timestamp without time zone
        END) AS txx_max_date,
    max(
        CASE
            WHEN rn_tnn_min = 1 THEN tnn_min
            ELSE NULL::double precision
        END) AS tnn_min,
    max(
        CASE
            WHEN rn_tnn_min = 1 THEN tnn_min_date
            ELSE NULL::timestamp without time zone
        END) AS tnn_min_date
   FROM ranked
  GROUP BY station_code, season_id;

CREATE VIEW "public"."v_records_absolus_par_type" AS
 SELECT 'all_time'::text AS period_type,
    NULL::text AS period_value,
    'TX'::text AS record_type,
    m.station_code,
    s.name AS station_name,
    s.departement AS department,
    m.txx_max AS record_value,
    m.txx_max_date AS record_date
   FROM v_records_absolus m
     JOIN v_station_records s ON s.station_code = m.station_code
UNION ALL
 SELECT 'all_time'::text AS period_type,
    NULL::text AS period_value,
    'TN'::text AS record_type,
    m.station_code,
    s.name AS station_name,
    s.departement AS department,
    m.tnn_min AS record_value,
    m.tnn_min_date AS record_date
   FROM v_records_absolus m
     JOIN v_station_records s ON s.station_code = m.station_code
UNION ALL
 SELECT 'season'::text AS period_type,
    m.season AS period_value,
    'TX'::text AS record_type,
    m.station_code,
    s.name AS station_name,
    s.departement AS department,
    m.txx_max AS record_value,
    m.txx_max_date AS record_date
   FROM v_records_absolus_par_saison m
     JOIN v_station_records s ON s.station_code = m.station_code
UNION ALL
 SELECT 'season'::text AS period_type,
    m.season AS period_value,
    'TN'::text AS record_type,
    m.station_code,
    s.name AS station_name,
    s.departement AS department,
    m.tnn_min AS record_value,
    m.tnn_min_date AS record_date
   FROM v_records_absolus_par_saison m
     JOIN v_station_records s ON s.station_code = m.station_code
UNION ALL
 SELECT 'month'::text AS period_type,
    m.month::text AS period_value,
    'TX'::text AS record_type,
    m.station_code,
    s.name AS station_name,
    s.departement AS department,
    m.txx_max AS record_value,
    m.txx_max_date AS record_date
   FROM mv_records_absolus_par_mois m
     JOIN v_station_records s ON s.station_code = m.station_code
UNION ALL
 SELECT 'month'::text AS period_type,
    m.month::text AS period_value,
    'TN'::text AS record_type,
    m.station_code,
    s.name AS station_name,
    s.departement AS department,
    m.tnn_min AS record_value,
    m.tnn_min_date AS record_date
   FROM mv_records_absolus_par_mois m
     JOIN v_station_records s ON s.station_code = m.station_code;

CREATE VIEW "public"."v_records_battus" AS
 WITH tx_all AS (
         SELECT q.station_code AS "NUM_POSTE",
            q.date AS "AAAAMMJJ",
            q.tx AS val,
            max(q.tx) OVER (PARTITION BY q.station_code ORDER BY q.date ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) AS prev_val
           FROM v_quotidienne q
          WHERE q.tx IS NOT NULL
        ), tn_all AS (
         SELECT q.station_code AS "NUM_POSTE",
            q.date AS "AAAAMMJJ",
            q.tn AS val,
            min(q.tn) OVER (PARTITION BY q.station_code ORDER BY q.date ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) AS prev_val
           FROM v_quotidienne q
          WHERE q.tn IS NOT NULL
        ), tx_monthly AS (
         SELECT q.station_code AS "NUM_POSTE",
            q.date AS "AAAAMMJJ",
            q.tx AS val,
            EXTRACT(month FROM q.date)::integer AS month_num,
            max(q.tx) OVER (PARTITION BY q.station_code, (EXTRACT(month FROM q.date)) ORDER BY q.date ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) AS prev_val
           FROM v_quotidienne q
          WHERE q.tx IS NOT NULL
        ), tn_monthly AS (
         SELECT q.station_code AS "NUM_POSTE",
            q.date AS "AAAAMMJJ",
            q.tn AS val,
            EXTRACT(month FROM q.date)::integer AS month_num,
            min(q.tn) OVER (PARTITION BY q.station_code, (EXTRACT(month FROM q.date)) ORDER BY q.date ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) AS prev_val
           FROM v_quotidienne q
          WHERE q.tn IS NOT NULL
        ), tx_seasonal AS (
         SELECT q.station_code AS "NUM_POSTE",
            q.date AS "AAAAMMJJ",
            q.tx AS val,
                CASE EXTRACT(month FROM q.date)::integer
                    WHEN 12 THEN 'winter'::text
                    WHEN 1 THEN 'winter'::text
                    WHEN 2 THEN 'winter'::text
                    WHEN 3 THEN 'spring'::text
                    WHEN 4 THEN 'spring'::text
                    WHEN 5 THEN 'spring'::text
                    WHEN 6 THEN 'summer'::text
                    WHEN 7 THEN 'summer'::text
                    WHEN 8 THEN 'summer'::text
                    WHEN 9 THEN 'autumn'::text
                    WHEN 10 THEN 'autumn'::text
                    WHEN 11 THEN 'autumn'::text
                    ELSE NULL::text
                END AS season_val,
            max(q.tx) OVER (PARTITION BY q.station_code, (
                CASE EXTRACT(month FROM q.date)::integer
                    WHEN 12 THEN 'winter'::text
                    WHEN 1 THEN 'winter'::text
                    WHEN 2 THEN 'winter'::text
                    WHEN 3 THEN 'spring'::text
                    WHEN 4 THEN 'spring'::text
                    WHEN 5 THEN 'spring'::text
                    WHEN 6 THEN 'summer'::text
                    WHEN 7 THEN 'summer'::text
                    WHEN 8 THEN 'summer'::text
                    WHEN 9 THEN 'autumn'::text
                    WHEN 10 THEN 'autumn'::text
                    WHEN 11 THEN 'autumn'::text
                    ELSE NULL::text
                END) ORDER BY q.date ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) AS prev_val
           FROM v_quotidienne q
          WHERE q.tx IS NOT NULL
        ), tn_seasonal AS (
         SELECT q.station_code AS "NUM_POSTE",
            q.date AS "AAAAMMJJ",
            q.tn AS val,
                CASE EXTRACT(month FROM q.date)::integer
                    WHEN 12 THEN 'winter'::text
                    WHEN 1 THEN 'winter'::text
                    WHEN 2 THEN 'winter'::text
                    WHEN 3 THEN 'spring'::text
                    WHEN 4 THEN 'spring'::text
                    WHEN 5 THEN 'spring'::text
                    WHEN 6 THEN 'summer'::text
                    WHEN 7 THEN 'summer'::text
                    WHEN 8 THEN 'summer'::text
                    WHEN 9 THEN 'autumn'::text
                    WHEN 10 THEN 'autumn'::text
                    WHEN 11 THEN 'autumn'::text
                    ELSE NULL::text
                END AS season_val,
            min(q.tn) OVER (PARTITION BY q.station_code, (
                CASE EXTRACT(month FROM q.date)::integer
                    WHEN 12 THEN 'winter'::text
                    WHEN 1 THEN 'winter'::text
                    WHEN 2 THEN 'winter'::text
                    WHEN 3 THEN 'spring'::text
                    WHEN 4 THEN 'spring'::text
                    WHEN 5 THEN 'spring'::text
                    WHEN 6 THEN 'summer'::text
                    WHEN 7 THEN 'summer'::text
                    WHEN 8 THEN 'summer'::text
                    WHEN 9 THEN 'autumn'::text
                    WHEN 10 THEN 'autumn'::text
                    WHEN 11 THEN 'autumn'::text
                    ELSE NULL::text
                END) ORDER BY q.date ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING) AS prev_val
           FROM v_quotidienne q
          WHERE q.tn IS NOT NULL
        )
 SELECT 'all_time'::text AS period_type,
    NULL::text AS period_value,
    'TX'::text AS record_type,
    r."NUM_POSTE" AS station_code,
    s.name AS station_name,
    s.departement AS department,
    r.val AS record_value,
    r."AAAAMMJJ" AS record_date
   FROM tx_all r
     JOIN v_station_records s ON s.station_code = r."NUM_POSTE"
  WHERE (r.prev_val IS NULL OR r.val > r.prev_val) AND r."AAAAMMJJ" >= (s.first_temperature_date + '50 years'::interval)
UNION ALL
 SELECT 'all_time'::text AS period_type,
    NULL::text AS period_value,
    'TN'::text AS record_type,
    r."NUM_POSTE" AS station_code,
    s.name AS station_name,
    s.departement AS department,
    r.val AS record_value,
    r."AAAAMMJJ" AS record_date
   FROM tn_all r
     JOIN v_station_records s ON s.station_code = r."NUM_POSTE"
  WHERE (r.prev_val IS NULL OR r.val < r.prev_val) AND r."AAAAMMJJ" >= (s.first_temperature_date + '50 years'::interval)
UNION ALL
 SELECT 'month'::text AS period_type,
    r.month_num::text AS period_value,
    'TX'::text AS record_type,
    r."NUM_POSTE" AS station_code,
    s.name AS station_name,
    s.departement AS department,
    r.val AS record_value,
    r."AAAAMMJJ" AS record_date
   FROM tx_monthly r
     JOIN v_station_records s ON s.station_code = r."NUM_POSTE"
  WHERE (r.prev_val IS NULL OR r.val > r.prev_val) AND r."AAAAMMJJ" >= (s.first_temperature_date + '50 years'::interval)
UNION ALL
 SELECT 'month'::text AS period_type,
    r.month_num::text AS period_value,
    'TN'::text AS record_type,
    r."NUM_POSTE" AS station_code,
    s.name AS station_name,
    s.departement AS department,
    r.val AS record_value,
    r."AAAAMMJJ" AS record_date
   FROM tn_monthly r
     JOIN v_station_records s ON s.station_code = r."NUM_POSTE"
  WHERE (r.prev_val IS NULL OR r.val < r.prev_val) AND r."AAAAMMJJ" >= (s.first_temperature_date + '50 years'::interval)
UNION ALL
 SELECT 'season'::text AS period_type,
    r.season_val AS period_value,
    'TX'::text AS record_type,
    r."NUM_POSTE" AS station_code,
    s.name AS station_name,
    s.departement AS department,
    r.val AS record_value,
    r."AAAAMMJJ" AS record_date
   FROM tx_seasonal r
     JOIN v_station_records s ON s.station_code = r."NUM_POSTE"
  WHERE (r.prev_val IS NULL OR r.val > r.prev_val) AND r."AAAAMMJJ" >= (s.first_temperature_date + '50 years'::interval)
UNION ALL
 SELECT 'season'::text AS period_type,
    r.season_val AS period_value,
    'TN'::text AS record_type,
    r."NUM_POSTE" AS station_code,
    s.name AS station_name,
    s.departement AS department,
    r.val AS record_value,
    r."AAAAMMJJ" AS record_date
   FROM tn_seasonal r
     JOIN v_station_records s ON s.station_code = r."NUM_POSTE"
  WHERE (r.prev_val IS NULL OR r.val < r.prev_val) AND r."AAAAMMJJ" >= (s.first_temperature_date + '50 years'::interval);

CREATE VIEW "public"."v_station_classe_123" AS
 SELECT station_code,
    name,
    departement,
    is_open,
    station_type,
    lon,
    lat,
    alt,
    is_public,
    classe_recente,
    date_de_creation,
    date_de_fermeture,
    annee_de_creation,
    annee_de_fermeture,
    first_temperature_date
   FROM v_station_classe_1234 s
  WHERE classe_recente <= 3;

CREATE VIEW "public"."v_station_classe_1234" AS
 SELECT station_code,
    name,
    departement,
    is_open,
    station_type,
    lon,
    lat,
    alt,
    is_public,
    classe_recente,
    date_de_creation,
    date_de_fermeture,
    annee_de_creation,
    annee_de_fermeture,
    first_temperature_date
   FROM v_station_qualifiee_hexagone s
  WHERE classe_recente <= 4;

CREATE VIEW "public"."v_station_deviation" AS
 SELECT station_code,
    name,
    departement,
    is_open,
    station_type,
    lon,
    lat,
    alt,
    is_public,
    classe_recente,
    date_de_creation,
    date_de_fermeture,
    annee_de_creation,
    annee_de_fermeture,
    first_temperature_date
   FROM v_station_classe_1234 s
  WHERE first_temperature_date < '1997-01-01 00:00:00'::timestamp without time zone;

CREATE VIEW "public"."v_station_itn" AS
 SELECT station_code,
    name,
    departement,
    is_open,
    station_type,
    lon,
    lat,
    alt,
    is_public,
    classe_recente,
    date_de_creation,
    date_de_fermeture,
    first_temperature_date
   FROM v_station_qualifiee_hexagone s
  WHERE station_code = ANY (ARRAY['06088001'::bpchar, '13054001'::bpchar, '14137001'::bpchar, '16089001'::bpchar, '20148001'::bpchar, '21473001'::bpchar, '25056001'::bpchar, '26198001'::bpchar, '29075001'::bpchar, '30189001'::bpchar, '31069001'::bpchar, '33281001'::bpchar, '35281001'::bpchar, '36063001'::bpchar, '44020001'::bpchar, '45055001'::bpchar, '47091001'::bpchar, '51183001'::bpchar, '51449002'::bpchar, '54526001'::bpchar, '58160001'::bpchar, '59343001'::bpchar, '63113001'::bpchar, '64549001'::bpchar, '66136001'::bpchar, '67124001'::bpchar, '69029001'::bpchar, '72181001'::bpchar, '73054001'::bpchar, '75114001'::bpchar, '86027001'::bpchar]);

CREATE VIEW "public"."v_station_qualifiee_hexagone" AS
 WITH station_classe_recente AS (
         SELECT station_classe.station_code,
            station_classe.classe
           FROM station_classe
          WHERE station_classe.date_fin IS NULL
        )
 SELECT DISTINCT ON (s.id) s.id AS station_code,
    s.nom AS name,
    s.departement,
    s."posteOuvert" AS is_open,
    s."typePoste" AS station_type,
    s.lon,
    s.lat,
    s.alt,
    s."postePublic" AS is_public,
    scr.classe AS classe_recente,
    scd.date_de_creation,
    scd.date_de_fermeture,
    EXTRACT(year FROM scd.date_de_creation)::integer AS annee_de_creation,
    EXTRACT(year FROM scd.date_de_fermeture)::integer AS annee_de_fermeture,
    ftd.first_temperature_date
   FROM "Station" s
     JOIN station_creation_date scd ON s.id = scd.station_code
     LEFT JOIN station_classe_recente scr ON s.id = scr.station_code
     JOIN mv_first_temperature_date ftd ON s.id = ftd.station_code
  WHERE s."typePoste" <= 3 AND s.departement < 96;

CREATE VIEW "public"."v_station_records" AS
 SELECT station_code,
    name,
    departement,
    is_open,
    station_type,
    lon,
    lat,
    alt,
    is_public,
    classe_recente,
    date_de_creation,
    date_de_fermeture,
    annee_de_creation,
    annee_de_fermeture,
    first_temperature_date
   FROM v_station_classe_123 s
  WHERE first_temperature_date <= (now() - '50 years'::interval);

